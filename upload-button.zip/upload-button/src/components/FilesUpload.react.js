/* eslint no-console: 0*/

import $ from 'jquery'
import React, {Component} from 'react';
import PropTypes from 'prop-types';

/**
 * FilesUpload is an example component.
 * It takes a list of `label`, and
 * displays buttons to upload files
 */



export default class FilesUpload extends Component {


  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e) {


      e.preventDefault()

      var component_id = this.props.id;
      var uploadUrl = this.props.uploadUrl;

      var form_data = new FormData($('#'+component_id+'-upload-file')[0]);

      $('#'+component_id+'-upload-file-btn').prop('disabled',true);

      $.ajax({
            type: 'POST',
            url: uploadUrl,
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            async: false,
            success: function(data) {
              console.log(data);
            }
        });
      // do something with the file
        $('#'+component_id+'-upload-file-btn').prop('disabled',false);

    }

    render() {


        var component_id = this.props.id;
        var textButton= this.props.textButton

        var fileLabels=this.props.label.split(',').map((name, index) =>

          <div key={index} >
          <label  for={'file_'+index}> {name}</label>
          <input  name={name} type="file" />
          </div>
        );

        return (

          <div class='dash-upload-form-upload'>
          <form id={component_id+'-upload-file'}
          method="post"
          enctype="multipart/form-data">
          { fileLabels }
          <button id={component_id+'-upload-file-btn'} type="button"
          onClick={this.handleSubmit} class='dash-upload-button-upload'> {textButton}</button>
          </form>
          </div>




        );
    }


}

FilesUpload.propTypes = {
    /**
     * The ID used to identify this compnent in Dash callbacks
     */
    id: PropTypes.string,

    /**
     * A set of labels for the files to upload
     */
    label: PropTypes.string.isRequired,

    /**
     * A set of labels for the files to upload
     */
    textButton: PropTypes.string,

    /**
     * upload url for ajax request
     */
    uploadUrl: PropTypes.string.isRequired,

    /**
     * Dash-assigned callback that should be called whenever any of the
     * properties change
     */
    setProps: PropTypes.func
};


FilesUpload.defaultProps = { textButton: 'Upload' };
