/* eslint-disable import/prefer-default-export */
import FilesUpload from './components/FilesUpload.react';

export {
    FilesUpload
};
